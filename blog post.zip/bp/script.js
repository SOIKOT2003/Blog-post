document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const createMobileNav = () => {
        const header = document.querySelector('header');
        const nav = document.querySelector('nav');
        
        // Create mobile menu button
        const mobileMenuBtn = document.createElement('button');
        mobileMenuBtn.classList.add('mobile-menu-btn');
        mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
        mobileMenuBtn.style.display = 'none';
        
        // Add mobile menu button to header
        header.querySelector('.container').appendChild(mobileMenuBtn);
        
        // Add mobile menu functionality
        mobileMenuBtn.addEventListener('click', function() {
            nav.classList.toggle('active');
            this.innerHTML = nav.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
        
        // Add mobile styles
        const style = document.createElement('style');
        style.textContent = `
            @media (max-width: 768px) {
                header .container {
                    position: relative;
                }
                
                .mobile-menu-btn {
                    display: block !important;
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    cursor: pointer;
                    color: #333;
                }
                
                nav {
                    position: absolute;
                    top: 100%;
                    left: 0;
                    right: 0;
                    background-color: #fff;
                    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
                    padding: 20px;
                    display: none;
                }
                
                nav.active {
                    display: block;
                }
                
                nav ul {
                    flex-direction: column;
                    align-items: center;
                }
                
                nav ul li {
                    margin: 10px 0;
                    width: 100%;
                    text-align: center;
                }
                
                nav ul li a {
                    display: block;
                    padding: 10px;
                }
            }
        `;
        document.head.appendChild(style);
    };
    
    // Initialize mobile navigation for smaller screens
    if (window.innerWidth <= 768) {
        createMobileNav();
    }
    
    window.addEventListener('resize', function() {
        if (window.innerWidth <= 768 && !document.querySelector('.mobile-menu-btn')) {
            createMobileNav();
        }
    });
    
    // Newsletter Form Submission
    const newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const emailInput = this.querySelector('input[type="email"]');
            const email = emailInput.value.trim();
            
            if (email) {
                // In a real application, you would send this to a server
                console.log('Newsletter subscription for:', email);
                
                // Show success message
                const successMessage = document.createElement('div');
                successMessage.classList.add('success-message');
                successMessage.textContent = 'Thank you for subscribing!';
                successMessage.style.color = '#0066cc';
                successMessage.style.marginTop = '10px';
                successMessage.style.fontWeight = 'bold';
                
                // Remove any existing success message
                const existingMessage = newsletterForm.querySelector('.success-message');
                if (existingMessage) {
                    existingMessage.remove();
                }
                
                newsletterForm.appendChild(successMessage);
                emailInput.value = '';
                
                // Remove success message after 3 seconds
                setTimeout(() => {
                    successMessage.remove();
                }, 3000);
            }
        });
    }
    
    // Add "Read More" functionality
    const readMoreLinks = document.querySelectorAll('.read-more');
    readMoreLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // In a real application, this would navigate to the full blog post
            // For this demo, we'll just show an alert
            const postTitle = this.closest('.post-content').querySelector('h3').textContent;
            alert(`You clicked to read more about "${postTitle}". In a real blog, this would take you to the full article.`);
        });
    });
    
    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    window.scrollTo({
                        top: target.offsetTop - 100,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // Add scroll-to-top button
    const createScrollTopButton = () => {
        const scrollBtn = document.createElement('button');
        scrollBtn.classList.add('scroll-top-btn');
        scrollBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
        document.body.appendChild(scrollBtn);
        
        // Style the button
        scrollBtn.style.position = 'fixed';
        scrollBtn.style.bottom = '20px';
        scrollBtn.style.right = '20px';
        scrollBtn.style.backgroundColor = '#0066cc';
        scrollBtn.style.color = '#fff';
        scrollBtn.style.border = 'none';
        scrollBtn.style.borderRadius = '50%';
        scrollBtn.style.width = '50px';
        scrollBtn.style.height = '50px';
        scrollBtn.style.fontSize = '1.2rem';
        scrollBtn.style.cursor = 'pointer';
        scrollBtn.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
        scrollBtn.style.display = 'none';
        scrollBtn.style.transition = 'opacity 0.3s ease';
        
        // Show/hide button based on scroll position
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                scrollBtn.style.display = 'block';
                scrollBtn.style.opacity = '1';
            } else {
                scrollBtn.style.opacity = '0';
                setTimeout(() => {
                    if (window.pageYOffset <= 300) {
                        scrollBtn.style.display = 'none';
                    }
                }, 300);
            }
        });
        
        // Scroll to top when clicked
        scrollBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    };
    
    createScrollTopButton();
    
    // Add a simple dark mode toggle
    const createDarkModeToggle = () => {
        const darkModeToggle = document.createElement('button');
        darkModeToggle.classList.add('dark-mode-toggle');
        darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        darkModeToggle.title = 'Toggle Dark Mode';
        
        // Style the button
        darkModeToggle.style.position = 'fixed';
        darkModeToggle.style.bottom = '80px';
        darkModeToggle.style.right = '20px';
        darkModeToggle.style.backgroundColor = '#333';
        darkModeToggle.style.color = '#fff';
        darkModeToggle.style.border = 'none';
        darkModeToggle.style.borderRadius = '50%';
        darkModeToggle.style.width = '50px';
        darkModeToggle.style.height = '50px';
        darkModeToggle.style.fontSize = '1.2rem';
        darkModeToggle.style.cursor = 'pointer';
        darkModeToggle.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
        darkModeToggle.style.zIndex = '100';
        
        document.body.appendChild(darkModeToggle);
        
        // Check for saved theme preference
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-mode');
            darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            darkModeToggle.style.backgroundColor = '#f8f9fa';
            darkModeToggle.style.color = '#333';
        }
        
        // Toggle dark mode
        darkModeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('theme', 'dark');
                this.innerHTML = '<i class="fas fa-sun"></i>';
                this.style.backgroundColor = '#f8f9fa';
                this.style.color = '#333';
            } else {
                localStorage.setItem('theme', 'light');
                this.innerHTML = '<i class="fas fa-moon"></i>';
                this.style.backgroundColor = '#333';
                this.style.color = '#fff';
            }
        });
        
        // Add dark mode styles
        const darkModeStyles = document.createElement('style');
        darkModeStyles.textContent = `
            body.dark-mode {
                background-color: #1a1a1a;
                color: #f8f9fa;
            }
            
            body.dark-mode header,
            body.dark-mode .post,
            body.dark-mode .widget {
                background-color: #2d2d2d;
                color: #f8f9fa;
            }
            
            body.dark-mode header h1 {
                color: #66b3ff;
            }
            
            body.dark-mode nav ul li a {
                color: #f8f9fa;
            }
            
            body.dark-mode nav ul li a:hover,
            body.dark-mode nav ul li a.active {
                background-color: #66b3ff;
            }
            
            body.dark-mode .post-content h3 {
                color: #f8f9fa;
            }
            
            body.dark-mode .widget h3 {
                color: #f8f9fa;
                border-bottom-color: #444;
            }
            
            body.dark-mode .widget ul li a {
                color: #f8f9fa;
            }
            
            body.dark-mode .widget ul li a:hover {
                color: #66b3ff;
            }
            
            body.dark-mode .newsletter {
                background-color: #2d2d2d;
            }
            
            body.dark-mode .newsletter h3 {
                color: #f8f9fa;
            }
            
            body.dark-mode .newsletter input {
                background-color: #1a1a1a;
                color: #f8f9fa;
                border-color: #444;
            }
            
            body.dark-mode .read-more {
                color: #66b3ff;
            }
            
            body.dark-mode .read-more:hover {
                color: #99ccff;
            }
        `;
        document.head.appendChild(darkModeStyles);
    };
    
    createDarkModeToggle();
}); 