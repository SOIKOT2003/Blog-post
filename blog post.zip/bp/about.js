document.addEventListener('DOMContentLoaded', function() {
    // Animate skill bars on scroll
    const animateSkillBars = () => {
        const skillBars = document.querySelectorAll('.skill-level');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Get the width from the style attribute
                    const width = entry.target.style.width;
                    
                    // Animate from 0 to the specified width
                    entry.target.style.width = '0';
                    setTimeout(() => {
                        entry.target.style.transition = 'width 1s ease-in-out';
                        entry.target.style.width = width;
                    }, 200);
                    
                    // Unobserve after animation
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        skillBars.forEach(bar => {
            observer.observe(bar);
        });
    };
    
    // Animate timeline items on scroll
    const animateTimeline = () => {
        const timelineItems = document.querySelectorAll('.timeline-item');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateX(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });
        
        timelineItems.forEach(item => {
            // Set initial styles
            item.style.opacity = '0';
            item.style.transform = 'translateX(-20px)';
            item.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            
            observer.observe(item);
        });
    };
    
    // Animate project items on scroll
    const animateProjects = () => {
        const projectItems = document.querySelectorAll('.project-item');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        projectItems.forEach((item, index) => {
            // Set initial styles with staggered delay
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            item.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            
            observer.observe(item);
        });
    };
    
    // Animate profile section
    const animateProfile = () => {
        const profileSection = document.querySelector('.profile-section');
        const profileImage = document.querySelector('.profile-image');
        const profileDetails = document.querySelector('.profile-details');
        
        if (profileSection) {
            profileSection.style.opacity = '0';
            profileSection.style.transform = 'translateY(20px)';
            profileSection.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            
            setTimeout(() => {
                profileSection.style.opacity = '1';
                profileSection.style.transform = 'translateY(0)';
            }, 300);
        }
        
        if (profileImage) {
            profileImage.style.opacity = '0';
            profileImage.style.transform = 'translateX(-20px)';
            profileImage.style.transition = 'opacity 0.8s ease 0.4s, transform 0.8s ease 0.4s';
            
            setTimeout(() => {
                profileImage.style.opacity = '1';
                profileImage.style.transform = 'translateX(0)';
            }, 300);
        }
        
        if (profileDetails) {
            profileDetails.style.opacity = '0';
            profileDetails.style.transform = 'translateX(20px)';
            profileDetails.style.transition = 'opacity 0.8s ease 0.6s, transform 0.8s ease 0.6s';
            
            setTimeout(() => {
                profileDetails.style.opacity = '1';
                profileDetails.style.transform = 'translateX(0)';
            }, 300);
        }
    };
    
    // Initialize animations
    animateProfile();
    animateSkillBars();
    animateTimeline();
    animateProjects();
    
    // Add hover effect to project images
    const projectItems = document.querySelectorAll('.project-item');
    projectItems.forEach(item => {
        const img = item.querySelector('img');
        
        item.addEventListener('mouseenter', () => {
            img.style.transform = 'scale(1.05)';
            img.style.transition = 'transform 0.5s ease';
        });
        
        item.addEventListener('mouseleave', () => {
            img.style.transform = 'scale(1)';
        });
    });
    
    // Add print resume functionality
    const addPrintButton = () => {
        const profileSection = document.querySelector('.profile-section');
        
        if (profileSection) {
            const printButton = document.createElement('button');
            printButton.classList.add('print-resume');
            printButton.innerHTML = '<i class="fas fa-print"></i> Print Resume';
            printButton.style.position = 'absolute';
            printButton.style.top = '20px';
            printButton.style.right = '20px';
            printButton.style.backgroundColor = '#0066cc';
            printButton.style.color = '#fff';
            printButton.style.border = 'none';
            printButton.style.borderRadius = '4px';
            printButton.style.padding = '8px 15px';
            printButton.style.fontSize = '0.9rem';
            printButton.style.cursor = 'pointer';
            printButton.style.display = 'flex';
            printButton.style.alignItems = 'center';
            printButton.style.gap = '5px';
            printButton.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
            
            // Make profile section position relative for absolute positioning
            profileSection.style.position = 'relative';
            
            profileSection.appendChild(printButton);
            
            // Add print functionality
            printButton.addEventListener('click', () => {
                window.print();
            });
            
            // Add hover effect
            printButton.addEventListener('mouseenter', () => {
                printButton.style.backgroundColor = '#004c99';
                printButton.style.transition = 'background-color 0.3s ease';
            });
            
            printButton.addEventListener('mouseleave', () => {
                printButton.style.backgroundColor = '#0066cc';
            });
            
            // Add print styles
            const printStyles = document.createElement('style');
            printStyles.textContent = `
                @media print {
                    header, footer, .newsletter, .about-hero, .print-resume, 
                    .scroll-top-btn, .dark-mode-toggle {
                        display: none !important;
                    }
                    
                    body {
                        background-color: white !important;
                        color: black !important;
                    }
                    
                    .about-container {
                        margin: 0 !important;
                        padding: 0 !important;
                    }
                    
                    .profile-section, .about-card {
                        box-shadow: none !important;
                        border: 1px solid #eee !important;
                        break-inside: avoid !important;
                    }
                    
                    .project-item {
                        break-inside: avoid !important;
                    }
                }
            `;
            document.head.appendChild(printStyles);
        }
    };
    
    addPrintButton();
    
    // Add smooth scroll for anchor links within the about page
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    window.scrollTo({
                        top: target.offsetTop - 100,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}); 