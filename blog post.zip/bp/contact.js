document.addEventListener('DOMContentLoaded', function() {
    // Contact Form Handling
    const contactForm = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();
            
            // Validate form
            if (!name || !email || !subject || !message) {
                showFormMessage('Please fill in all fields', 'error');
                return;
            }
            
            if (!isValidEmail(email)) {
                showFormMessage('Please enter a valid email address', 'error');
                return;
            }
            
            // In a real application, you would send this data to a server
            // For this demo, we'll just show a success message
            console.log('Form submitted:', { name, email, subject, message });
            
            // Show success message
            showFormMessage('Your message has been sent successfully! I will get back to you soon.', 'success');
            
            // Reset form
            contactForm.reset();
        });
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    function showFormMessage(text, type) {
        formMessage.textContent = text;
        formMessage.className = 'form-message ' + type;
        
        // Hide message after 5 seconds
        setTimeout(() => {
            formMessage.textContent = '';
            formMessage.className = 'form-message';
        }, 5000);
    }
    
    // Animate elements on scroll
    const animateOnScroll = () => {
        const elements = [
            ...document.querySelectorAll('.contact-info, .contact-form-container'),
            ...document.querySelectorAll('.skill-item'),
            ...document.querySelectorAll('.project-card'),
            ...document.querySelectorAll('.reference-card')
        ];
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        elements.forEach((element, index) => {
            // Set initial styles
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = `opacity 0.5s ease ${index * 0.05}s, transform 0.5s ease ${index * 0.05}s`;
            
            // Add class for animation completion
            element.addEventListener('transitionend', () => {
                element.style.opacity = '';
                element.style.transform = '';
                element.style.transition = '';
            }, { once: true });
            
            observer.observe(element);
        });
    };
    
    // Animate contact items with staggered delay
    const animateContactItems = () => {
        const items = document.querySelectorAll('.contact-item, .social-links a, .education-item');
        
        items.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateX(-20px)';
            item.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            
            setTimeout(() => {
                item.style.opacity = '1';
                item.style.transform = 'translateX(0)';
            }, 300);
            
            // Remove inline styles after animation completes
            item.addEventListener('transitionend', () => {
                item.style.opacity = '';
                item.style.transform = '';
                item.style.transition = '';
            }, { once: true });
        });
    };
    
    // Animate skill icons
    const animateSkillIcons = () => {
        const skillIcons = document.querySelectorAll('.skill-icon');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('pulse');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        skillIcons.forEach(icon => {
            // Add CSS for pulse animation
            const style = document.createElement('style');
            style.textContent = `
                .skill-icon.pulse {
                    animation: pulse 0.5s ease-in-out;
                }
                
                @keyframes pulse {
                    0% { transform: scale(1); }
                    50% { transform: scale(1.2); }
                    100% { transform: scale(1); }
                }
            `;
            document.head.appendChild(style);
            
            observer.observe(icon);
        });
    };
    
    // Add hover effect to project cards
    const addProjectHoverEffects = () => {
        const projectCards = document.querySelectorAll('.project-card');
        
        projectCards.forEach(card => {
            const icon = card.querySelector('.project-icon');
            
            card.addEventListener('mouseenter', () => {
                icon.style.transform = 'scale(1.2) rotate(10deg)';
                icon.style.transition = 'transform 0.3s ease';
            });
            
            card.addEventListener('mouseleave', () => {
                icon.style.transform = 'scale(1) rotate(0)';
            });
        });
    };
    
    // Initialize animations
    setTimeout(() => {
        animateOnScroll();
        animateContactItems();
        animateSkillIcons();
        addProjectHoverEffects();
    }, 500);
    
    // Add CSS for general animations
    const addAnimationStyles = () => {
        const style = document.createElement('style');
        style.textContent = `
            .contact-info, .contact-form-container, .skill-item, .project-card, .reference-card {
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            
            .contact-info.animate, .contact-form-container.animate, 
            .skill-item.animate, .project-card.animate, .reference-card.animate {
                opacity: 1 !important;
                transform: translateY(0) !important;
            }
        `;
        document.head.appendChild(style);
    };
    
    addAnimationStyles();
    
    // Add profile image hover effect
    const profileImage = document.querySelector('.profile-image');
    if (profileImage) {
        profileImage.addEventListener('mouseenter', () => {
            profileImage.style.transform = 'scale(1.05)';
            profileImage.style.transition = 'transform 0.3s ease';
        });
        
        profileImage.addEventListener('mouseleave', () => {
            profileImage.style.transform = 'scale(1)';
        });
    }
}); 